# Tarea 5 - IS061 - Resultados

Equipo: _(nombres de los integrantes)_

## 1. Medición

Cifras obtenidas con `python cadena.py` (cadenas cargadas con los enteros de 0 a n-1;
`ultimos_pasos` leído justo después de cada llamada).

| n (nodos) | Dos pasadas | Liebre y tortuga |
| --- | --- | --- |
| 1.001 | 1.501 | 1.500 |
| 10.001 | 15.001 | 15.000 |
| 100.001 | 150.001 | 150.000 |

## 2. Lectura

Las dos columnas dan casi lo mismo (alrededor de 1,5 n), así que la liebre y la tortuga
**no gana tiempo**: gana que no necesita saber cuántos nodos hay. Resuelve el medio en
**una sola entrada** por el primer nodo, mientras que las dos pasadas entran **dos veces**
(una para contar y otra para caminar hasta la mitad). Eso importa cuando recorrer cuesta
más que el simple avance de un puntero o cuando no se puede repetir el recorrido: una
cadena que se lee de disco o de red, una que otro proceso modifica entre las dos pasadas
(el conteo quedaría desactualizado), o una cuyo largo no se conoce. En una cadena en
memoria, con el largo a mano, las dos maneras son equivalentes en la práctica.

En la sencilla hay que guardar el siguiente antes de pisarlo porque `invertir` hace que
`actual.siguiente` apunte hacia atrás; si no se guardó antes, el resto de la cadena queda
sin referencia y se pierde. En la doble no hace falta: al intercambiar `siguiente` y
`anterior`, el antiguo `siguiente` queda guardado en `anterior`, y por ahí se avanza.

Detalle de implementación: con número par de nodos la tortuga debe quedar en el primer
central, índice (n-1)//2. Por eso el bucle de la liebre exige que pueda dar un salto
completo de dos (`liebre.siguiente.siguiente is not None`); con la condición habitual la
tortuga quedaría en el segundo central.

## 3. Reparto del trabajo

| Integrante | Parte |
| --- | --- |
| _(nombre 1)_ | `Cadena`: agregar, `__len__`, `a_lista`, `invertir` |
| _(nombre 2)_ | `medio_dos_pasadas`, `medio` y la medición |
| _(nombre 3)_ | `Doble` completa |
| Todos | Pruebas y este documento; cada integrante revisó y puede explicar toda la entrega |

## 4. Fuentes

No se tomó código de fuentes externas; todo se escribió a partir de las sesiones 8 y 9.
_(Si usaron alguna fuente, declárenla aquí.)_
