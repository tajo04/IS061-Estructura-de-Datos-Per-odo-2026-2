"""Tarea 5 - IS061 Estructura de Datos: listas ligadas sencilla y doble.

Cadena -> ligada sencilla (NodoSencillo)
Doble  -> ligada doble   (NodoDoble)

Reglas de la tarea:
  1. Los datos viven en los nodos (ninguna estructura guarda una lista de Python).
  2. agregar NO recorre la cadena: se guarda el puntero al ultimo nodo.
  3. invertir NO crea nodos ni mueve datos: solo cambia punteros.

Un "paso" es cada ejecucion de `actual = actual.siguiente`, incluida la que
deja el puntero en None. Se guarda en self.ultimos_pasos.
"""


class NodoSencillo:
    def __init__(self, dato):
        self.dato = dato
        self.siguiente = None


class NodoDoble:
    def __init__(self, dato):
        self.dato = dato
        self.siguiente = None
        self.anterior = None


class Cadena:
    """Lista ligada sencilla con puntero a la cabeza y al ultimo nodo."""

    def __init__(self):
        self.cabeza = None
        self.ultimo = None      # regla 2: evita recorrer la cadena al agregar
        self._tamano = 0
        self.ultimos_pasos = 0  # pasos de la ultima medicion de medio

    def agregar(self, dato):
        nodo = NodoSencillo(dato)
        if self.cabeza is None:
            self.cabeza = nodo
        else:
            self.ultimo.siguiente = nodo
        self.ultimo = nodo
        self._tamano += 1

    def __len__(self):
        return self._tamano

    def a_lista(self):
        datos = []
        actual = self.cabeza
        while actual is not None:
            datos.append(actual.dato)
            actual = actual.siguiente
        return datos

    def medio_dos_pasadas(self):
        """Pasada 1: cuenta los nodos. Pasada 2: camina hasta el indice (n-1)//2."""
        pasos = 0

        # Primera entrada por la cabeza: contar.
        n = 0
        actual = self.cabeza
        while actual is not None:
            n += 1
            actual = actual.siguiente
            pasos += 1          # incluye el paso final que deja actual en None

        if n == 0:
            self.ultimos_pasos = pasos
            return None

        # Segunda entrada por la cabeza: caminar hasta la mitad.
        actual = self.cabeza
        for _ in range((n - 1) // 2):
            actual = actual.siguiente
            pasos += 1

        self.ultimos_pasos = pasos
        return actual.dato

    def medio(self):
        """Liebre y tortuga: una sola pasada. Cada vuelta cuesta 3 pasos
        (1 de la tortuga + 2 de la liebre)."""
        pasos = 0
        tortuga = self.cabeza
        liebre = self.cabeza

        # Se frena cuando la liebre no puede dar un salto completo de dos.
        # Con n par esto deja a la tortuga en el primero de los dos centrales,
        # es decir, en el indice (n-1)//2 (con "liebre.siguiente is not None"
        # sola, la tortuga quedaria en el segundo central).
        while (liebre is not None and liebre.siguiente is not None
               and liebre.siguiente.siguiente is not None):
            tortuga = tortuga.siguiente
            liebre = liebre.siguiente
            liebre = liebre.siguiente
            pasos += 3

        self.ultimos_pasos = pasos
        return None if tortuga is None else tortuga.dato

    def invertir(self):
        """Voltea los punteros nodo por nodo; no crea nodos ni mueve datos."""
        previo = None
        actual = self.cabeza
        self.ultimo = self.cabeza   # la vieja cabeza sera el nuevo ultimo
        while actual is not None:
            # Hay que guardar el siguiente ANTES de pisarlo: si no, al apuntar
            # actual.siguiente hacia atras se pierde el resto de la cadena.
            siguiente = actual.siguiente
            actual.siguiente = previo
            previo = actual
            actual = siguiente
        self.cabeza = previo


class Doble:
    """Lista ligada doble con punteros a la cabeza y a la cola."""

    def __init__(self):
        self.cabeza = None
        self.cola = None
        self._tamano = 0

    def agregar(self, dato):
        nodo = NodoDoble(dato)
        if self.cabeza is None:
            self.cabeza = nodo
        else:
            nodo.anterior = self.cola   # enlaza en los dos sentidos
            self.cola.siguiente = nodo
        self.cola = nodo
        self._tamano += 1

    def __len__(self):
        return self._tamano

    def a_lista(self):
        datos = []
        actual = self.cabeza
        while actual is not None:
            datos.append(actual.dato)
            actual = actual.siguiente
        return datos

    def a_lista_al_reves(self):
        """Del ultimo al primero, usando los punteros `anterior`."""
        datos = []
        actual = self.cola
        while actual is not None:
            datos.append(actual.dato)
            actual = actual.anterior
        return datos

    def invertir(self):
        """Intercambia siguiente y anterior de cada nodo."""
        actual = self.cabeza
        while actual is not None:
            # Tras el intercambio, el viejo `siguiente` queda en `anterior`,
            # asi que no hace falta guardarlo aparte: se avanza por ahi.
            actual.siguiente, actual.anterior = actual.anterior, actual.siguiente
            actual = actual.anterior
        self.cabeza, self.cola = self.cola, self.cabeza


def _cargar(n):
    cadena = Cadena()
    for i in range(n):
        cadena.agregar(i)
    return cadena


if __name__ == "__main__":
    print(f"{'n (nodos)':>10} {'Dos pasadas':>12} {'Liebre y tortuga':>17}")
    for n in (1001, 10001, 100001):
        c = _cargar(n)
        c.medio_dos_pasadas()
        dos = c.ultimos_pasos          # se lee justo despues de cada llamada
        c.medio()
        liebre = c.ultimos_pasos
        print(f"{n:>10,} {dos:>12,} {liebre:>17,}".replace(",", "."))
