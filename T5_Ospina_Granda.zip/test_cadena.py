import unittest

from cadena import Cadena, Doble


def sencilla(datos):
    c = Cadena()
    for d in datos:
        c.agregar(d)
    return c


def doble(datos):
    d = Doble()
    for x in datos:
        d.agregar(x)
    return d


class PruebasCadena(unittest.TestCase):
    def test_agregar_conserva_orden_y_tamano(self):
        c = sencilla([4, 5, 6])
        self.assertEqual(c.a_lista(), [4, 5, 6])
        self.assertEqual(len(c), 3)

    def test_medio_con_impar(self):
        c = sencilla([10, 20, 30, 40, 50])
        self.assertEqual(c.medio(), 30)
        self.assertEqual(c.medio_dos_pasadas(), 30)

    def test_medio_con_par_es_el_primero_de_los_centrales(self):
        c = sencilla([1, 2, 3, 4])
        self.assertEqual(c.medio(), 2)
        self.assertEqual(c.medio_dos_pasadas(), 2)

    def test_los_dos_medios_coinciden_en_muchos_tamanos(self):
        for n in range(1, 40):
            c = sencilla(range(n))
            self.assertEqual(c.medio(), c.medio_dos_pasadas())
            self.assertEqual(c.medio(), (n - 1) // 2)

    def test_invertir_y_luego_agregar(self):
        c = sencilla([1, 2, 3])
        c.invertir()
        self.assertEqual(c.a_lista(), [3, 2, 1])
        c.agregar(0)  # el puntero al ultimo debe haberse actualizado
        self.assertEqual(c.a_lista(), [3, 2, 1, 0])
        self.assertEqual(len(c), 4)

    def test_invertir_no_crea_nodos_ni_mueve_datos(self):
        c = sencilla(["a", "b", "c"])
        nodos = []
        actual = c.cabeza
        while actual:
            nodos.append(actual)
            actual = actual.siguiente
        c.invertir()
        invertidos = []
        actual = c.cabeza
        while actual:
            invertidos.append(actual)
            actual = actual.siguiente
        self.assertEqual([id(n) for n in invertidos], [id(n) for n in reversed(nodos)])
        self.assertEqual([n.dato for n in nodos], ["a", "b", "c"])

    def test_pasos_medidos_en_1001_nodos(self):
        c = sencilla(range(1001))
        c.medio_dos_pasadas()
        self.assertEqual(c.ultimos_pasos, 1501)
        c.medio()
        self.assertEqual(c.ultimos_pasos, 1500)

    # --- Casos de borde ---
    def test_borde_cadena_vacia(self):
        c = Cadena()
        self.assertEqual(len(c), 0)
        self.assertEqual(c.a_lista(), [])
        self.assertIsNone(c.medio())
        self.assertIsNone(c.medio_dos_pasadas())
        c.invertir()  # no debe fallar
        self.assertEqual(c.a_lista(), [])

    def test_borde_un_solo_nodo(self):
        c = sencilla([7])
        self.assertEqual(c.medio(), 7)
        self.assertEqual(c.medio_dos_pasadas(), 7)
        c.invertir()
        self.assertEqual(c.a_lista(), [7])


class PruebasDoble(unittest.TestCase):
    def test_agregar_enlaza_en_los_dos_sentidos(self):
        d = doble([1, 2, 3])
        self.assertEqual(d.a_lista(), [1, 2, 3])
        self.assertEqual(d.a_lista_al_reves(), [3, 2, 1])
        self.assertEqual(len(d), 3)

    def test_invertir_doble_y_seguir_agregando(self):
        d = doble([1, 2, 3, 4])
        d.invertir()
        self.assertEqual(d.a_lista(), [4, 3, 2, 1])
        self.assertEqual(d.a_lista_al_reves(), [1, 2, 3, 4])
        d.agregar(0)
        self.assertEqual(d.a_lista(), [4, 3, 2, 1, 0])
        self.assertEqual(d.a_lista_al_reves(), [0, 1, 2, 3, 4])

    def test_borde_doble_vacia_y_de_un_nodo(self):
        d = Doble()
        self.assertEqual(d.a_lista(), [])
        self.assertEqual(d.a_lista_al_reves(), [])
        d.invertir()
        self.assertEqual(len(d), 0)
        d.agregar(9)
        d.invertir()
        self.assertEqual(d.a_lista(), [9])
        self.assertEqual(d.a_lista_al_reves(), [9])


if __name__ == "__main__":
    unittest.main()
